/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repetitivas;

/**
 *
 * @author DAM 6J
 */
public class Ejercicio1Repetitivas {
    
    public static void main(String[] args) {
        
        int num=1;
        
        
        while(num<=50){//que se visualicen los 50 primeros números, incluyo el 50 pq empiezo en 1
            
           
            System.out.print(num);
            num=num+1;
        
        
        }
        
    }
    
}
